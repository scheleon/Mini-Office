## Swagger API Documentation
On localhost - http://localhost:8080/swagger-ui.html
